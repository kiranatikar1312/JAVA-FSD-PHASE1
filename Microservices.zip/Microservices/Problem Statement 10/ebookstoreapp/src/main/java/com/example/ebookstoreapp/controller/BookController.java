package com.example.ebookstoreapp.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.example.ebookstoreapp.domain.Book;
import com.example.ebookstoreapp.service.BookService;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping(value = "/books", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public Book addBook(@RequestBody Book book) {
        return bookService.addBook(book);
    }

//    @PutMapping(value = "/books/{book_id}", produces = MediaType.APPLICATION_JSON_VALUE,
//            consumes = MediaType.APPLICATION_JSON_VALUE)
//    @ResponseStatus(HttpStatus.OK)
//    public Book updateBook(@RequestBody Book book) {
//        return bookService.updateBook(book);
//    }
    
    @PutMapping(value = "/books/{book_id}", produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public Book updateBook(@PathVariable("book_id") Long bookId, @RequestBody Book updatedBook) {
        Book existingBook = bookService.getBookById(bookId);

        if (existingBook != null) {
            existingBook.setTitle(updatedBook.getTitle());
            existingBook.setAuthor(updatedBook.getAuthor());
            existingBook.setPublisher(updatedBook.getPublisher());
            existingBook.setYear(updatedBook.getYear());

            return bookService.updateBook(existingBook);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found");
        }
    }


    @DeleteMapping(value = "/books/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteBookById(@PathVariable("id") Long id) {
        bookService.deleteBookById(id);
    }

    @GetMapping(value = "/books/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Book getBookById(@PathVariable("id") Long id) {
        return bookService.getBookById(id);
    }

    @GetMapping(value = "/books", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }

    @GetMapping(value = "/books/title/{title}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Book> getAllBooksByTitle(@PathVariable("title") String title) {
        return bookService.findByTitle(title);
    }

    @GetMapping(value = "/books/publisher/{publisher}", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Book> getAllBooksByPublisher(@PathVariable("publisher") String publisher) {
        return bookService.findByPublisher(publisher);
    }

    @GetMapping(value = "/books", params = "year", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Book> getAllBooksByYear(@RequestParam("year") int year) {
        return bookService.findByYear(year);
    }
}

