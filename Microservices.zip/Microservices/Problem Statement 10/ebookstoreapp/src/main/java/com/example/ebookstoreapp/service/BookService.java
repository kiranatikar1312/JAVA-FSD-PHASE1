package com.example.ebookstoreapp.service;


import java.util.List;

import com.example.ebookstoreapp.domain.Book;

public interface BookService {
    Book addBook(Book book);
    Book updateBook(Book book);
    List<Book> getAllBooks();
    Book getBookById(Long id);
    void deleteBookById(Long id);
    List<Book> findByTitle(String title);
    List<Book> findByPublisher(String publisher);
    List<Book> findByYear(int year);
}
