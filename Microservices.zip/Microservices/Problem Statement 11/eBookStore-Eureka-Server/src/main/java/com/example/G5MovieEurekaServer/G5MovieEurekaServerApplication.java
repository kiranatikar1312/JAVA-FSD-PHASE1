package com.example.G5MovieEurekaServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class G5MovieEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(G5MovieEurekaServerApplication.class, args);
	}

}
