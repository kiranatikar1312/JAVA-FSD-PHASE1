package com.example.ebookstoreapp;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.example.ebookstoreapp.domain.Book;
import com.example.ebookstoreapp.repository.BookRepository;

@SpringBootApplication
@EnableEurekaClient
public class EbookstoreappApplication {

    public static void main(String[] args) {
        SpringApplication.run(EbookstoreappApplication.class, args);
    }

    @Bean
    public CommandLineRunner initData(BookRepository bookRepository) {
        return args -> {
            bookRepository.save(new Book("Book Title 1", "Author 1", "Publisher 1", 2020));
            bookRepository.save(new Book("Book Title 2", "Author 2", "Publisher 2", 2018));
            bookRepository.save(new Book("Book Title 3", "Author 3", "Publisher 3", 2022));
        };
    }
}
