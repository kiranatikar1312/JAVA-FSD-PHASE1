package com.example.eBookStoreConsumerFeign;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class BookServiceFallback implements BookServiceProxy {

	@Override
	public Book getBookById(Long id) {
		return new Book(id,"Updated Title", "Updated Author", "Updated Publisher", 2027);
	}

	@Override
	public List<Book> getAllBooks(){
		return new ArrayList<Book>();
	}
}
