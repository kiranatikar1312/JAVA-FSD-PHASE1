package com.example.eBookStoreConsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@Service
public class BookService {
	
	@Autowired
	private RestTemplate restTemplate;

	@Retry(name = "book-service")
	@CircuitBreaker(name = "book-service", fallbackMethod = "fallbackMethodforGetBookById")
	public Book getBookById(long id) {
		Book book = restTemplate.getForObject("http://book-service/books/" + id, Book.class);
		return book;
	}

	public Book fallbackMethodforGetBookById(long id, Throwable cause) {
		System.out.println("Exception Failed with the message:====>" + cause.getMessage());
		return new Book(id,"Res Title", "Res Author", "Res Publisher", 0);
	}
}