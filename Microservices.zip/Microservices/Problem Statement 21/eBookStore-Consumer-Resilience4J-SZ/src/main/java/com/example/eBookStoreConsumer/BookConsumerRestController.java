package com.example.eBookStoreConsumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.eBookStoreConsumer.Book;

@RestController
@Scope("request")
public class BookConsumerRestController {
	@Autowired
	private BookService bookservice;

	private Logger log = LoggerFactory.getLogger(BookConsumerRestController.class);

	@GetMapping("/get-books/{id}")
	    public Book getBookById(@PathVariable("id") long id) {
			log.debug("In getBookById with Id:"+ id);
			Book book = bookservice.getBookById(id);
			log.debug("In getBookById with return value Book:" + book);
	        return book;
	    }
}